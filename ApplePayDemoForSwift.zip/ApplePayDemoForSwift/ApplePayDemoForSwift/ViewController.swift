//
//  ViewController.swift
//  ApplePayDemoForSwift
//
//  Created by admin on 16/2/25.
//  Copyright © 2016年 Brian Tsui. All rights reserved.
//

import UIKit
import PassKit //ApplePay Required

class ViewController: UIViewController,PKPaymentAuthorizationViewControllerDelegate {
    //实际上为了处理由PKPaymentAuthorizationViewController返回的付款信息，您需要实现PKPaymentAuthorizationViewControllerDelegate这个协议。它有两个必须实现的方法，分别如下：
//    -(void)paymentAuthorizationViewController:didAuthorizePayment:completion:
//    -(void)paymentAuthorizationViewControllerDidFinish://它是负责调用用来切换支付页面的dismissViewControllerAnimated:这个方法的。
    
    
    var payButton : PKPaymentButton?// 必须创建苹果要求的 支付专用的按钮
    var payment : PKPaymentRequest?//支付请求
    var paymentAuthorVC : PKPaymentAuthorizationViewController?//支付授权页面
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // 初始化支付按钮的样式 和风格
        payButton = PKPaymentButton.init(type: PKPaymentButtonType.Buy, style: PKPaymentButtonStyle.WhiteOutline)
        payButton!.frame = CGRect(x: 0, y: 0, width: 100, height: 44)
        payButton!.center = self.view.center
        self.view.addSubview(payButton!)
        payButton!.addTarget(self, action: "Pay:", forControlEvents: UIControlEvents.TouchUpInside)
        
 
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //执行支付按钮
    func Pay(sender:UIButton){
        
        if (PKPaymentAuthorizationViewController.canMakePayments()){
            
            self.payment = PKPaymentRequest.init()
            let widget1 = PKPaymentSummaryItem.init(label: "大白菜", amount: 0.05)
            let widget2 = PKPaymentSummaryItem.init(label: "花心大萝卜", amount: -0.02)
            let total = PKPaymentSummaryItem.init(label: "Github超市", amount: 0.03)//这里用了手动计算...
            
   
            payment?.currencyCode = "CNY"//货币代码:人民币
            payment?.countryCode = "CN"//国家代码:CN
            
            // 在 developer.apple.com member center 里设置的 merchantID
            payment?.merchantIdentifier = "merchant.com.mmeichi"// #Replace "me" with your Apple Merchant ID#
            
            // Fixbug: 原来设置为 `PKMerchantCapabilityCredit` 在真机上无法回调 `didAuthorizePayment` 方法
            payment?.merchantCapabilities = [PKMerchantCapability.Capability3DS ,PKMerchantCapability.CapabilityCredit , PKMerchantCapability.CapabilityDebit , PKMerchantCapability.CapabilityEMV]
            
            //支持哪种结算网关
            payment?.supportedNetworks = [PKPaymentNetworkChinaUnionPay,PKPaymentNetworkPrivateLabel,PKPaymentNetworkMasterCard,PKPaymentNetworkVisa]

            //选择快递方式
            let freeShipping = PKShippingMethod.init(label: "包邮", amount: 0.00)
            freeShipping.identifier = "freeshipping"
            freeShipping.detail = "2-3天内到货"
            
            let expressShipping = PKShippingMethod(label: "顺丰", amount: 0.10)
            expressShipping.identifier = "expressshipping"
            expressShipping.detail = "1-2天内到货"
            payment!.shippingMethods = [freeShipping, expressShipping]

            
            //将账单汇总成了数组类型的支付信息
            payment?.paymentSummaryItems = [widget1,widget2,total]
            
    
            print("//////////////")
            print("Payment:\(payment)")
            print("//////////////")
            
            //初始化支付授权页面
            self.paymentAuthorVC = PKPaymentAuthorizationViewController.init(paymentRequest: self.payment!)
            
            //设置代理
            paymentAuthorVC?.delegate = self
            
            //弹出授权页面. 真机测试时, payment.merchantCapbilities 如果不支持你的真机,程序会崩溃.
            self.presentViewController(paymentAuthorVC!, animated: true, completion: nil)
            
        }
        
    }

    //实现 PKPaymentAuthorizationViewControllerDelegate 方法.
    func paymentAuthorizationViewController(controller: PKPaymentAuthorizationViewController, didAuthorizePayment payment: PKPayment, completion: (PKPaymentAuthorizationStatus) -> Void) {
        
        NSLog("did authorize payment token:\(payment.token),\(payment.token.transactionIdentifier)")
        completion(PKPaymentAuthorizationStatus.Success)//状态为支付授权成功
    }
    
    //支付结束时
    func paymentAuthorizationViewControllerDidFinish(controller: PKPaymentAuthorizationViewController) {
        print("paymentAuthorizationViewController  DidFinish")
        //支付完毕时,退出页面.
        controller.dismissViewControllerAnimated(true, completion: nil)
    }
    
    //选择快递方式
    func paymentSummaryItemsForShippingMethod(shipping: PKShippingMethod) -> ([PKPaymentSummaryItem]) {
        //这里可以建立商品信息

        return []//返回商品数组
    }
    //其他方法
    func paymentAuthorizationViewController(controller: PKPaymentAuthorizationViewController, didSelectShippingContact contact: PKContact, completion: (PKPaymentAuthorizationStatus, [PKShippingMethod], [PKPaymentSummaryItem]) -> Void) {
        print("didSelectShippingContact")
    }
    
    func paymentAuthorizationViewController(controller: PKPaymentAuthorizationViewController, didSelectShippingMethod shippingMethod: PKShippingMethod, completion: (PKPaymentAuthorizationStatus, [PKPaymentSummaryItem]) -> Void) {
        print("didSelectShippingMethod")
    }

    func paymentAuthorizationViewController(controller: PKPaymentAuthorizationViewController, didSelectShippingAddress address: ABRecord, completion: (PKPaymentAuthorizationStatus, [PKShippingMethod], [PKPaymentSummaryItem]) -> Void) {
        print("didSelectShippingAddress")
    }
    
    func paymentAuthorizationViewControllerWillAuthorizePayment(controller: PKPaymentAuthorizationViewController) {
        print("WillAuthorizePayment")
    }
    


}

